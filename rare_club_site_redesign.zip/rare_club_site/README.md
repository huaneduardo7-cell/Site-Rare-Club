# RARE CLUB — site demonstrativo

## Como abrir
Abra `index.html` em um navegador moderno. O catálogo, filtros, navegação entre páginas e sacola funcionam no navegador.

## O que já funciona
- Layout responsivo para desktop e celular.
- Navegação por páginas via hash.
- Catálogo com filtros de categoria, tamanho, cor, preço e ordenação.
- Página de produto com escolha de tamanho.
- Sacola com quantidade, remoção, subtotal e persistência via localStorage.
- Busca, newsletter e formulários em modo demonstrativo.
- Páginas institucionais e modelos editáveis de políticas.

## Antes de vender de verdade
- Troque as imagens externas por fotografias autorizadas e finais da marca.
- Confirme preço, estoque, tamanhos, composição e cuidados com os fornecedores.
- Revise as políticas de privacidade, envio e devolução com orientação adequada.
- Conecte backend/CMS para gestão de produtos e pedidos.
- Integre frete e um provedor de pagamentos compatível com Pix/cartão. Não há processamento de pagamento real nesta versão.
- Implemente autenticação e administração segura se necessário.
- Configure domínio, analytics e SEO técnico para publicação.

## Nota técnica
É uma versão front-end estática, sem servidor, banco de dados ou painel administrativo. Imagens do Unsplash e fontes do Google Fonts dependem de conexão à internet. A sacola usa armazenamento local do navegador.


## Atualização de catálogo
O catálogo foi ampliado para 12 produtos demonstrativos e os preços de exemplo foram reduzidos para uma faixa mais acessível (camisetas em torno de R$ 59,90–R$ 84,90; moletom em torno de R$ 159,90; calças em torno de R$ 129,90–R$ 139,90; acessórios em torno de R$ 39,90–R$ 49,90). Esses valores são referências visuais, não cotações de custo ou preços finais de venda.
